@echo off
cd /d "%~dp0"
call "iDezign TOOLKIT.bat"
